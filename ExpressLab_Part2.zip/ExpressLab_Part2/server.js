"use strict";
//npm init
const express = require("express");
//npm install express
const app = express();
//nodemon
const items = require("./routes");
app.use(express.static("./public"));
app.use(express.json());
app.use("/", items);
app.listen(8080, () => {
    console.log("Server is running.");
});
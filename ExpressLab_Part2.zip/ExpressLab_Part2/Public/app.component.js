"use strict";

const items = {
    templateUrl: "component.html",

    // this is Injecting a service
    controller: ["CartService", function (CartService) {
        const vm = this;
        //running method called getAllItems which calls the service and bundles up the response and give it to us as a variable called vm.itemList. 
        // Now we can use it in our template url.
        CartService.getAllItems().then(response => {
            console.log(response);
            //response.data is now stored in vm.item.List
            //response.data is coming from our service
            vm.itemList = response.data;
        });

        // vm.deleteItem = function (item) {
        //     CartService.deleteItem(item).then(response => {
        //         vm.itemList = response.data;
        //         console.log(response);
        //     });
        // };
    }]

}


angular
    .module("App")
    .component("items", items)



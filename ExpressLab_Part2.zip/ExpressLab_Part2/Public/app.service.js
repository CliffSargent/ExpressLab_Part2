"use strict";
//$http is a type of request
function CartService($http) {
    // use const self for SERVICES not components
    const self = this;
    //1 method communicating to our backend and getting our cart items
    self.getAllItems = function(){
        return $http({ 
            method: "GET",
            url: "/items"
        })
    }

    // self.deleteItem = function(item){
    //     return $http({
    //         method: "DELETE",
    //         url: `/items/${item}`
    //     })
    // }

}

angular
.module("App")
.service("CartService", CartService);